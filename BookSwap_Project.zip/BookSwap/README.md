# BookSwap – Second-Hand Book Marketplace

A working PHP + MySQL web application based on the uploaded BookSwap PBL presentation.

## Features
- Student registration and login (passwords are hashed)
- Browse available academic books
- Search by title, author, subject and description
- Filter by subject, condition and maximum price
- Add book listings with branch, semester, condition, price and exchange option
- View book and seller details
- Send buy or exchange requests
- Sellers can accept or decline requests
- Manage own listings, mark books sold, relist or delete
- Responsive desktop and mobile layout
- MySQL persistence using PDO prepared statements

## Requirements
- Windows 10/11
- XAMPP (Apache + MySQL)
- A modern browser
- VS Code (optional)

## Setup in XAMPP
1. Install and open XAMPP.
2. Start **Apache** and **MySQL**.
3. Copy the complete `BookSwap` folder into `C:\xampp\htdocs\`.
4. Open `http://localhost/phpmyadmin`.
5. Select **Import**, choose `database.sql` from this project, then click **Import** / **Go**.
   - The SQL creates the `bookswap` database and its three tables.
6. Check `config.php`. Default XAMPP settings are host `localhost`, user `root`, empty password. If you set a MySQL password, update `$dbpass`.
7. Open `http://localhost/BookSwap/`.

## First use
1. Click **Join BookSwap** and create a student account.
2. Log in and choose **Sell a book**.
3. Add a book with title, author, subject and condition.
4. Open the Explore page in another browser/incognito session and create a second account to test buyer requests.
5. The seller can open **Requests** and accept or decline.
6. The seller can open **My listings** and mark the book sold when the handover is complete.

## Project structure
- `index.php` – home page, book catalogue, search and filters
- `register.php`, `login.php`, `logout.php` – account access
- `add_book.php`, `book.php` – listing and book details
- `request_book.php`, `requests.php` – buy/exchange request workflow
- `my_listings.php` – seller listing management
- `config.php` – database connection and shared helpers
- `database.sql` – database schema
- `assets/style.css`, `assets/app.js` – frontend styling and navigation

## Important real-world notes
This is a locally runnable full-stack college project, not yet a public production marketplace. It stores accounts and listings in MySQL and supports a real request workflow, but buyer and seller arrange payment and handover themselves. It does not process online payments, upload book photos, verify student identity, or send email/SMS notifications. Before public deployment, add HTTPS, verified college email, rate limiting, moderation/reporting, secure production secrets, backups, image upload validation/storage, and privacy/legal pages. Do not publish real student phone numbers without consent.

## Technology mapping from the presentation
Frontend: HTML, CSS, JavaScript  
Backend: PHP  
Database: MySQL  
Development: VS Code + XAMPP

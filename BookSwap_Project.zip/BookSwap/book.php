<?php
require_once "config.php";
$id=(int)($_GET["id"]??0);
$stmt=$pdo->prepare("SELECT b.*,u.name AS seller_name,u.email AS seller_email,u.phone AS seller_phone,u.college FROM books b JOIN users u ON b.user_id=u.id WHERE b.id=?");
$stmt->execute([$id]); $book=$stmt->fetch();
if(!$book){http_response_code(404);$page_title="Book not found";require "header.php";echo '<div class="empty-state"><h2>Book not found</h2><a href="index.php">Back to books</a></div>';require "footer.php";exit;}
$page_title=$book["title"]; require "header.php";
?>
<div class="detail-back"><a href="index.php">← Back to explore</a></div>
<div class="detail-layout"><div class="detail-cover cover-<?= (int)$book["id"]%5 ?>"><span class="cover-label"><?= e($book["subject"]) ?></span><strong><?= e($book["title"]) ?></strong><small><?= e($book["author"]) ?></small><i>BOOKSWAP</i></div><div class="detail-content"><div class="eyebrow"><?= e($book["subject"]) ?> · <?= e($book["branch"] ?: "Academic book") ?></div><h1><?= e($book["title"]) ?></h1><p class="detail-author">by <?= e($book["author"]) ?></p><div class="detail-price"><?= money($book["price"]) ?></div><div class="detail-tags"><span><?= e($book["book_condition"]) ?> condition</span><span><?= $book["exchange_available"]?"Exchange possible":"Sale listing" ?></span><span><?= e($book["status"]) ?></span></div><h3>About this book</h3><p class="detail-description"><?= nl2br(e($book["description"] ?: "The seller has not added a description.")) ?></p><div class="seller-card"><div class="seller-avatar"><?= e(strtoupper(substr($book["seller_name"],0,1))) ?></div><div><strong><?= e($book["seller_name"]) ?></strong><span><?= e($book["college"] ?: "BookSwap student member") ?></span></div></div>
<?php if($book["status"]==="available"): ?>
<?php if(logged_in() && (int)$book["user_id"]===(int)$_SESSION["user_id"]): ?><a class="btn btn-dark" href="my_listings.php">Manage your listing</a>
<?php elseif(logged_in()): ?><a class="btn btn-primary" href="request_book.php?id=<?= (int)$book["id"] ?>">Request this book <span>→</span></a>
<?php else: ?><a class="btn btn-primary" href="login.php">Log in to request this book <span>→</span></a><?php endif; ?>
<?php else: ?><div class="alert">This book is no longer available.</div><?php endif; ?>
<p class="safety-note">Safety tip: Meet in a public place on campus and check the book before completing the exchange.</p>
</div></div>
<?php require "footer.php"; ?>
